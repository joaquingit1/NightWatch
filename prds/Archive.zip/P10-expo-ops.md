# P10 — Expo Ops (July 26, 9:00-15:00; frozen code)

**Objective:** execute the two-layer demo all morning, catch every judge, and close each one with their track's ending. No building today; operating only.
**Read first:** `../PRD.md` sections 8.5, 8.6, 13; `../TRACK-ANSWERS.md`.

## Schedule
- 07:30 arrive; physical setup per P8 dry-run layout; dog on charger to 100%; spare battery staged.
- 08:15 T-30 checklist (PRD 8.6), full run, no shortcuts.
- 08:45 ambient show starts (rounds loop live BEFORE judges enter at 9:00; they must find it already working).
- 9:00-12:00 judges-only window: maximum vigilance; hourly full escort-and-wake spectacle on the hour; battery swap at the 30% alert during a low-traffic moment.
- 12:00-15:00 public window: kiosk diagnosis line for visitors (crowd magnet + Audience's Choice votes); stickers flowing; testimonials welcome.
- 15:00-15:30 teardown (venue requires clear-out by 15:30); return all borrowed hardware per provider rules.

## Roles (fixed, no swapping mid-morning)
- **Narrator (Dev C):** owns the script and all judge conversation; adapts the close per lanyard (Blue Box → mattress beat invitation; Dimensional → Rerun + ledger; engineer-type → engineer's tour).
- **Operator (Dev A):** director console + dog welfare; speaks only if asked technical operations questions; executes downgrades silently if needed.
- **Judge-catcher (Dev B):** watches the aisle for judge lanyards, warm-intercepts ("she's mid-round, 30 seconds, meanwhile look at the leaderboard: you might be on it"), manages the queue, hands stickers, answers perception questions when the narrator is occupied.

## Non-negotiables
- The whole team present the entire judging window (absence forfeits prizes per rules); at least one member demos to the public in the afternoon.
- Every judge interaction ends with the learned/built/change triad and the differentiation line.
- If a judge arrives during a failure: present anyway, narrate the degraded mode plainly, show the reel: stated confidence about known gaps, never concealment.
- Log every judge visit (who/track/questions/reaction) in a note; it guides which sponsors to follow up with and feeds the closing-ceremony conversations.
- Nobody argues with a judge. Skeptical question → factor breakdown, wall chart, or live re-demonstration, whichever answers it fastest.

## Acceptance (how we'll know we executed)
1. Ambient show uptime ≥90% of the judging window (downgrades count as uptime if presentable).
2. Zero judges walked past unengaged during 9:00-12:00.
3. Sponsor judges for every entered track were identified and got their tailored close.
4. Hardware returned, booth cleared by 15:30, all footage/data backed up before leaving the hall.
