# P8 — Hardening & Rehearsal (all three; parallel with P7)

**Objective:** make the 2.5-minute judge script boringly reliable and every failure mode a rehearsed downgrade, not a surprise. The bar: a zero-intervention streak of full judge simulations.
**Read first:** `../PRD.md` section 8.5 (the script) and 8.6 (T-30 checklist). **Blocked by:** I4.

## Workstreams

**Dev A: reliability engineering.**
- Replay regression harness: record N representative sessions (approach, diagnose, escort, wake, deter) via DimOS session recording; script that replays them against the current policy/perception and asserts expected PolicyEvent sequences; run before every push from now on. The count ("34 scenarios replay green") goes on the wall.
- Watchdogs: WebRTC reconnect wrapper in facade (auto-reconnect + PolicyEvent on drop/restore); module supervisor (restart perception/web on crash); battery alerting on director console.
- Fallback drills, each executed at least twice for real: full → fixed-zone (kill nav mid-run), fixed-zone → kiosk (kill facade), kiosk → replay mode (kill perception). Time each downgrade; target < 60 s to a stable presentable state.

**Dev B: perception hardening.**
- Expo-condition matrix at the actual booth spot at expo-like times: morning light, crowd backgrounds, multiple faces; fix or gate.
- Judge-lock behavior: verify largest/nearest-face locking with 5 people in frame; verify the "hold still" retry path.
- Latency re-check with final configuration; update the panel.

**Dev C: script & humans.**
- Rehearsal direction: run the count. **30+ full judge simulations**: a rotating teammate (and any borrowable stranger) plays a circulating judge who arrives mid-ambient-loop, interrupts, asks the six hard questions (PRD section 13) plus Blue Box and Dimensional specials; narrator + operator run the real script against the live system.
- Timing discipline: every rep timed; script trimmed until 2.5 min is comfortable, not rushed.
- Spiel variants drilled: standard, engineer's tour (60 s), Blue Box close (judge lies down beat: rehearse the invitation so it lands charming, not weird), Dimensional close, degraded-mode honesty lines.
- Booth physical setup dry run: screens sightlines at 3 m, mattress placement, patrol lane taped, props staged, sticker table.

## Acceptance
1. 30 full simulations logged (standup tally); final 10 with zero manual interventions outside the director console's legitimate skip function.
2. Reset drill: < 30 s from any state, 5 times consecutively.
3. All three fallback downgrades executed live in < 60 s each, presentable at each rung.
4. Replay harness green; count on the wall.
5. T-30 checklist executed start to finish once as a drill, timed.

## Guardrails
- Feature freeze at P8 start except: bugs found by rehearsal, and P7's flag decision. New ideas go to a `docs/post-hackathon.md` parking lot.
- Rehearse with the real voice clips at real volume in real noise; discovering the speaker is too quiet at 9 AM on judging day is a self-inflicted wound.
- Battery math for expo morning locked tonight: charge schedule + swap point on the director checklist.
