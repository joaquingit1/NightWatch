# P3 — Behavior: Policy, Navigation, Personality (Dev A lane; starts vs MOCK before P1 finishes dog work)

**Objective:** the full single-person care loop (TRIAGE → APPROACH → DIAGNOSE → PRESCRIBE → ESCORT → NAP_REGISTERED → WAKE_LADDER → CELEBRATE) runs autonomously: first against the mock facade in sim, then on the real dog in a premapped zone.
**Read first:** `00-OVERVIEW.md`. **Consumes:** C1 FatigueFrames (real from Dev B, or the stub generator), C4 facade (mock then real). **Produces:** C2 PolicyEvents. **Blocks:** I2, I3, P4.

## Tasks, in order

1. **`policy/escalation.py`:** explicit FSM with the exact states from the overview. Pure-python, testable without robot: `step(inputs) -> list[Action|PolicyEvent]`. Inputs: latest FatigueFrame(s), nap registry, clock, operator commands. Rules (initial; tune in rehearsal):
   - TRIAGE→APPROACH when a consented person's score ≥ 60 with confidence ≥ 0.6, rate-limited (do not re-approach the same person within 30 min of a decline).
   - DIAGNOSE: hold 15-20 s for quick-calibrated reading; if confidence stays < 0.5, speak `ask_look_at_me` once, then give up gracefully (PolicyEvent detail explains why).
   - PRESCRIBE: speak verdict clips (`verdict_score_NN` + `prescribe_nap_20`); acceptance = ring button (if integrated) OR operator key OR voice yes via Whisper; decline is a valid path (log, return to PATROL).
   - ESCORT: navigate_to("nap_zone") at low speed, periodic `observe()` person-check behind (follow-me-inverted); on arrival NAP_REGISTERED (wake deadline = onset + 20 min once onset detection exists (P4); until then, registration + 20 min).
   - WAKE_LADDER (`policy/wake_ladder.py`): ring vibrate (if present) → `say(wake_whisper_01)` at low volume → approach + `sport("Hello")` paw wave beside the mat. NEVER contact. Escalate at 30 s intervals; CELEBRATE (`Stretch` + `WiggleHips` + clip) on wake confirmation (movement detected or button).
   - Every transition emits a PolicyEvent (bilingual detail).
2. **`policy/director.py`:** hidden operator console (terminal is fine): keys for advance-step, reset-to-IDLE (<30 s, cancels navigation, clears target), e-stop (calls facade.stop()), scorer flag toggle, battery display from `status()`. Reset must be idempotent and safe from any state.
3. **Voice integration:** consume clip ids per the overview registry; coordinate the needed clip list with Dev C early (post the full list in standup by end of day; Dev C renders in P5).
4. **Sim/mock milestone (I2):** scripted FatigueFrame sequence drives the whole loop against MockFacade; PolicyEvents stream to the stub server ticker. This must pass before touching the dog.
5. **Real dog (I3):** premap the actual booth zone + patrol corridor (`unitree-go2-memory` → relocalization per P1 dry run); `tag_location` for `nap_zone`, `patrol_1..N`, `home`. Wire `DimosImageSource` so DIAGNOSE uses the dog camera; run the loop end to end with a teammate as the subject. Tune speeds (escort slow), approach distances (stop 1.2 m from people), and timings.
6. **Personality pass:** insert the kindness beats (sit briefly before speaking, pause after prescription, celebrate wake) as FSM sub-steps, not ad-hoc sleeps; all lines via clips.

## Acceptance
1. I2: full loop green against mock with a scripted score trajectory, PolicyEvents visible in ticker, zero manual intervention.
2. I3: full loop on the real dog in the mapped zone with a real person, 3 consecutive clean runs; decline path and give-up path each demonstrated once.
3. Director console: reset from mid-ESCORT to IDLE < 30 s; e-stop halts motion < 1 s.
4. `pytest tests/test_escalation.py` covers: approach rate-limit, confidence give-up, decline, wake escalation ordering, reset from every state.

## Guardrails
- The FSM decides, the LLM narrates: use the DimOS agent for natural-language flavor and operator Q&A, but state transitions are deterministic FSM logic (this is also the honest answer to "how much is the LLM doing").
- No physical contact with people in any state; approach stop-distance is a constant, not a tunable.
- If venue premapping in crowds fails, shrink to the fixed 3×3 m zone (the demo survives; note it and move on). Do not burn more than a half day on nav tuning.
