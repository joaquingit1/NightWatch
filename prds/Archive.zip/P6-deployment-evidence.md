# P6 — Deployment & Evidence (all three devs; the irreplaceable phase)

**Objective:** one real overnight run among actual hackers producing the three assets nothing else can produce: a populated Rest Ledger, the patrol timelapse, and the golden-run film. Treat tonight as a film shoot AND a data collection AND a system test, in that priority order: footage and data cannot be recreated tomorrow; bugs can be fixed tomorrow.
**Blocked by:** I4 (full loop integrated). If I4 slips, run a reduced deployment anyway (fixed zone, manual escort): real interactions still count.

## Roles tonight
- **Dev A (dog operator):** runs the rounds loop in the mapped zone; supervises every human interaction; battery rotation (swap at 30%); e-stop in pocket at all times.
- **Dev B (data):** capture stations for the drowsy harvest (KSS sessions from tired hackers; target ≥40 tonight); monitors perception quality in the wild, logs failures to stuck-log (do not hotfix during the shoot unless demo-fatal).
- **Dev C (producer):** films everything: phone/borrowed camera on tripod for the timelapse (dog patrolling rows of sleeping hackers; lock exposure); close-ups of diagnosis moments, escorts, paw-wave wakes, sticker handoffs; collects short spoken testimonials (10 s, consented, "it woke me exactly on time" energy). Shot list below.

## Run plan
1. Evening: announce in venue channels + walk the floor: "adopt the night watch dog, it will guard your nap tonight" (stickers + QR). Target ≥15 new adopters.
2. Night blocks (2-3 h): rounds loop live in the mapped zone with real nappers on the Blue Box mattress; every nap, pass, wake, and outcome flows to the ledger FOR REAL (no synthetic entries, ever: the ledger's integrity is the evidence's value).
3. Golden-run film: between live blocks, stage the full 2.5-min demo loop with best lighting and shoot it clean 3 times (wide + close coverage). This is the submission video spine and fallback rung 4 footage.
4. 3-4 AM: the timelapse hour (the venue's most cinematic sleep-deprivation window) + drowsy-harvest peak.

## Shot list (Dev C, minimum)
Timelapse of patrol among sleepers · diagnosis over-the-shoulder (screen + face + dog) · escort walk · StandDown guard beside sleeper + e-ink/printed sign · deterrence beat · wake ladder (whisper → paw wave → person stretches) · CELEBRATE wiggle · leaderboard screen with crowd · 3 testimonials · one wide "3 AM venue + dog silhouette" hero shot.

## Acceptance
1. Ledger: ≥8 real guided naps, ≥30 passes, ≥80% on-time wakes, ≥6 outcome ratings; `/api/ledger` timeline coherent.
2. Dataset: total sessions ≥100 with ≥15 KSS ≥7 entries (drowsy class secured).
3. Footage: all shot-list items on disk in two locations (laptop + phone/drive); golden run has 3 clean takes.
4. Stuck-log: tonight's field failures recorded with fixes-or-workarounds noted for P8.

## Guardrails
- Consent discipline is absolute: only adopters interacted with or identifiable on film; wide venue shots are fine, close-ups need a yes; never film toward the staff/donation-wall areas the venue rules protect.
- No code changes on the demo path during live blocks; hotfix window is between blocks with `smoke.py` re-run.
- Everyone sleeps ≥4 h tonight in shifts (the irony of building this product while destroying ourselves is a bad RED post).
