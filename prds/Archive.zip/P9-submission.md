# P9 — Submission (Dev C drives, all three review; HARD GATE July 26 1:00 AM)

**Objective:** everything submitted early, updated calmly, never racing the deadline. The portal opens July 25 12:00 noon: v1 goes in within two hours of opening.
**Read first:** `../TRACK-ANSWERS.md` (essays), `../PRD.md` sections 10, 14.

## Checklist with owners

**Dev C (assembler):**
1. Portal v1 (by ~14:00 July 25): name 守夜犬 Night Watch; one-liner + description from PRD section 1; tech list; theme = Reverse (as verified in P0); tracks per the cut-line rule below; teammates entered EXACTLY per prize-payment rules; placeholder media. Update iteratively; final media by 23:00.
2. Media: 16:9 cover (hero shot from P6, title + thesis overlay); carousel: diagnosis moment, escort, wake paw, leaderboard, wall charts, dataset card; submission video (≤90 s) cut from the golden run: hook (diagnosis) → job (rounds/wake) → evidence (ledger + charts) → vision line. TapNow credits if faster than manual cutting.
3. RED post (required): patrol timelapse + wake moment + the dataset story ("我们在中国最不睡觉的地方，建了一个守护睡觉的机器人"), tags #adventurex #夏天属于黑客松; post link into portal. Daily build-in-public posts should already exist if Track 7 is entered.

**Dev A (repo):**
4. Repo final: tag `#adventurex2026` in the description/README; README = short technical report (P7); `docs/stuck-log.md` polished (it feeds essays); LICENSE; dataset in `data/export/`; commit history untouched (no squashing, no history rewrites: the audit reads it); final `smoke.py` + `pytest` green on main.

**Dev B (essays):**
5. Track essays finalized from `TRACK-ANSWERS.md`: fill [BUILD-LOG] slots with the 3-4 best real stuck-log entries; update all numbers (sessions, subjects, AUC, naps, wakes, adopters) to actuals; Dimensional Q4 updated to the real booth conditions confirmed for expo.

**All three (23:00):** track cut-line review: for each conditional track (24/21/7/23/22), one question: is the integration live in the demo? Yes → enter with essay; No → drop without sentiment. Then joint read-through of the whole submission, submit final, screenshot confirmation.

## Acceptance
1. Portal shows submitted status before 00:30 (30 min buffer minimum); confirmation screenshot in standup.
2. Every entered track has its integration demonstrably live and its essay filled with actuals.
3. RED note live and linked; repo README renders with charts; last commit before deadline.
4. No teammate name/payment-detail errors (read the member list twice; prizes pay strictly per this list).

## Guardrails
- Numbers in essays and video must match the ledger exactly; one inflated number found by a judge poisons all the real ones.
- Nothing new gets built on July 25 evening; P9 is assembly and truth-checking only.
- If the portal has a submission bug (a team lost a track entry to one last year), screenshot everything and email/Feishu the organizers before the deadline, not after.
