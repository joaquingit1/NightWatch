# P4 — Ops: Rounds, Ledger, Breathing, Deterrence (A + B + C converge)

**Objective:** single-person care becomes multi-sleeper infrastructure: the scheduler runs rounds over concurrent naps, the ledger records everything, breathing verification and belongings checks run at nap passes, and sleep-onset detection starts the wake timer.
**Read first:** `00-OVERVIEW.md`, TDD sections 6-8. **Blocked by:** P3 (I3) for the robot parts; ledger/scheduler logic starts against mock anytime after P0.

## Dev A: `policy/scheduler.py` (RoundsScheduler)
- Model: stops = active naps (check every `interval` 3-5 min; hard wake deadlines) + patrol waypoints (soft). Travel times from tag-to-tag measured constants (measure once on the premap, hardcode table).
- Solve: exact search (DFS + admissible bound) at N ≤ 10 stops, replan on every world change (new nap, wake done, manual event) and every 30 s. Deadline feasibility check: if a wake deadline is at risk, it preempts everything (PolicyEvent explains the reroute; this is demo narration gold).
- Park behavior between sweeps: navigate_to("home"), `sport("StandDown")` (battery).
- Output: ordered stop list + ETA per stop, published as JSON on `/api/plan` (Dev C renders it); PolicyEvent on every replan with reason.
- `tests/test_scheduler.py`: deadline preemption, feasibility alarm (impossible deadlines flagged, nearest-deadline-first fallback), replan stability (no oscillation between equal plans).

## Dev B: nap-perception modules
- **`perception/breathing.py`** (TDD 8): torso ROI from pose landmarks on a still sleeper; optical-flow vertical displacement; band-pass 0.1-0.5 Hz; FFT peak → rpm + SNR-based confidence; abstain below threshold. Standalone demo: `python -m nightwatch.perception.breathing` on a lying teammate shows live waveform + rpm. Output into `passes.breathing_rpm` and a small waveform PNG per pass for the UI.
- **Sleep-onset detector** (in `perception/fatigue.py` or new module): onset = sustained stillness (movement below threshold for 120 s) AND breathing settled (rpm stable), evaluated during NAP_REGISTERED. Emits onset event → policy sets wake deadline = onset + prescribed duration. This is the Blue Box rubric feature; it must be visibly narrated in the UI ("入睡检测: 03:12 睡着了，从现在开始计时").
- **Belongings scene-diff:** at NAP_REGISTERED, capture reference frame of the sleeper's desk/things; each PASS_CHECK, re-observe from approximately the same tag pose, compute a coarse diff (SSIM or ORB-match on the ROI); on significant change, DETER: PolicyEvent + `say(deter_polite_01)` + save evidence frame path to `passes`.

## Dev C: `ledger/` + surfaces
- **`ledger/db.py` + `schema.sql`** per overview tables; every PolicyEvent, pass, nap, outcome persisted; person baselines readable by Dev B's calib.
- **`/api/ledger`, `/api/leaderboard`** (fatigue leaderboard: top sustained scores + hours-without-rest from sedentary tracking; aliases only, adopters only, opt-out honored).
- **Rest-outcome survey:** post-wake one-tap (better/same) via the adopter's phone page or a button the narrator offers; writes `naps.outcome`.
- **Sedentary-hours signal:** from patrol observations of adopters (reid sightings at same tag over time) → feeds `FatigueFactors.sedentary_hours` via a small query function Dev B calls.

## Acceptance
1. Two simulated naps (teammates) + patrol waypoints: scheduler visibly interleaves passes, preempts for the nearer wake deadline, both wakes on time (±60 s); `/api/plan` shows the live route.
2. Breathing waveform + rpm live on a real lying person, abstains when they move.
3. Onset detection: narrated onset within ~2.5 min of a teammate genuinely settling; wake deadline visibly re-anchored to onset.
4. Deterrence: reaching for the sleeper's bag triggers DETER + evidence frame within 10 s of the pass (or immediately if dog is present at the stop).
5. Ledger round-trip: after a 30-min session, `/api/ledger` reconstructs the timeline (naps, passes, wakes, outcomes) accurately.

## Guardrails
- Scheduler stays exact-search simple; no OR-tools, no metaheuristics: N is small and explainability is the point.
- Breathing is a verification aid with abstention, never a medical claim (also the phrase to use with judges).
- All P4 features degrade gracefully to P3 behavior via flags (`SCHEDULER=False` → single-nap mode); demo path must survive any one of them being turned off.
