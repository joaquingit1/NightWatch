# P2 — Perception & Capture (Dev B lane + Dev C's capture app; parallel with P1)

**Objective:** the FatigueEngine works live on a laptop webcam with pose-corrected EAR and threshold scoring, and the capture app is collecting KSS-labeled sessions from real participants. Data not collected today is gone forever, so the capture app is the single most schedule-critical artifact in this phase.
**Read first:** `00-OVERVIEW.md`, `../SLEEPINESS-PIPELINE-TDD.md` (authoritative for all algorithms here). **Blocks:** I1, I2, P7. **Blocked by:** nothing (webcam only; the dog is irrelevant to this phase).

## Dev B tasks (perception core), in order

1. **`perception/sources.py`:** frame source abstraction: `WebcamSource(fps=30)` and `DimosImageSource(topic="color_image")` yielding identical `(ts, frame_bgr)` tuples. Config flag `CAMERA_SOURCE` selects. Only WebcamSource needs to work in P2.
2. **`perception/features.py` (THE shared FeatureExtractor):** MediaPipe Face Landmarker (3D landmarks + facial transformation matrix + blendshapes enabled) + MediaPipe Pose. Emits `FeatureVector` per frame exactly per contract. Quality gating: emit `quality` from landmark presence/confidence; downstream must ignore frames with quality < 0.5. **This module is imported by both runtime and the capture app; it must stay dependency-light and deterministic.** Ship `tests/golden/`: 5 recorded short clips + expected FeatureVector series (tolerance-based comparison) as a regression test.
3. **`perception/ear.py`:** naive EAR + pose-corrected EAR (inverse facial-transform on 3D eye landmarks → canonical frame → EAR; see TDD 3.2). Produce the wall artifact now: `python -m nightwatch.perception.ear --headsweep` records 20 s, saves `web/static/wall/ear_correction.png` (naive swinging vs corrected flat).
4. **`perception/calib.py`:** per-person baseline (open-eye corrected-EAR percentile tracker). Two modes per TDD 5: `quick` (population default, refined ~15 s) and `full` (from a capture session). Baselines persist via Ledger `persons.baseline_json` (write through a function Dev C exposes in `ledger/db.py`; stub it locally if not ready, flag in standup).
5. **`perception/fatigue.py`:** rolling 60 s window (1 s hop) over FeatureVectors → `FatigueFactors` → threshold scorer S1 (PERCLOS > 0.15 major, blink_ms_p90 > 400 major, nod_count minor, slump minor; fixed interpretable weights, documented in the module docstring) → `FatigueFrame` with confidence (inputs: face size, quality, pose extremity, calib_state). Publishes: python callback + annotated frame (bbox, factor readout, score dial burned in with OpenCV).
6. **Robustness matrix:** test live on all 3 devs + volunteers: glasses/no, bright/dim, sitting/slumped, 1 m/2 m, someone walking behind. Record pass/fail table in `docs/standup.md`; fix what's fixable, gate the rest via confidence.
7. **(flagged, only after 1-6 accepted) `perception/eye_cnn.py`:** small CNN (≤1M params) on landmark-derived eye crops, pretrained on MRL+CEW (train script in `models/`, can run on HyperAI). Feeds `eye_cnn_p`; `EYE_CNN=False` by default until it beats geometric EAR on the golden clips with glasses.

## Dev C tasks (capture app; ships before anything else in your lane)

1. **`capture/app.py`:** web page (phone-friendly, served from laptop) driving a 60-90 s webcam session: consent screen (analysis consent mandatory; raw-video consent separate checkbox; bilingual zh-first) → live preview with Dev B's annotated overlay (self-viewing is the incentive) → KSS 1-9 picker with the standard Chinese/English scale wording → hours-awake, glasses, lighting → writes `CaptureRecord` (features via the SAME FeatureExtractor import) to `data/sessions/`, raw video only if consented.
2. **Adoption flow (`POST /api/adopt`):** name-alias + consent → person row in ledger + prints/pairs the sticker moment. Capture session doubles as `full` calibration for adopters.
3. **Collection ops:** stand at high-traffic spots with a sign; target ≥40 sessions day one. Track counts in standup. Repeat-session prompts for adopters (each new KSS level from a known person is the most valuable data).

## Acceptance
1. Live demo: any team member sits at the webcam, gets a lock in ≤3 s, calibration ≤20 s, plausible score with factor breakdown; forcing drowsy behavior (long eye closures, head nods) visibly moves the score; confidence gate demonstrably suppresses output when face is turned away or occluded.
2. `--headsweep` plot exists and shows the correction working.
3. Golden-vector test green in CI-ish runner (`pytest tests/`).
4. ≥20 capture sessions on disk from ≥10 distinct people, KSS spread ≥3 values; records load back and re-featurize identically (round-trip test).
5. Annotated stream consumable by the stub/real web server (I1 ready).

## Guardrails
- Thresholds and weights come from the TDD; do not invent new metrics or "improve" formulas beyond it without a standup note.
- No model training in this phase (P7). No dog integration in this phase (P3/P4 wire `DimosImageSource`).
- Privacy invariants are load-bearing for judging: no raw video without the checkbox, no identification of non-adopters, and the capture data dir is gitignored.
