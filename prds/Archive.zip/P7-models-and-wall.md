# P7 — Models & Wall (Dev B primary, Dev C support; parallel with P8 rehearsal)

**Objective:** train and honestly evaluate the learned scorers on the venue dataset, decide the feature flag, and finalize the engineering wall. Everything here is additive: if all of P7 were deleted, the demo still runs on thresholds.
**Read first:** TDD sections 4, 6, 7. **Blocked by:** P6 (dataset). **Blocks:** wall printing, submission claims.

## Dev B tasks
1. **Dataset assembly (`models/dataset.py`):** load all CaptureRecords; windowize with the SAME windowing code as runtime (import from `perception/fatigue.py`, do not reimplement); label = KSS mapped to 3 classes (1-3 / 4-6 / 7-9); if drowsy n is thin, collapse to 2-class and say so on the wall. Emit a dataset card (n sessions, n subjects, class balance, glasses %, capture conditions).
2. **S2 (`models/train_lgbm.py`):** LightGBM on window statistics. **Splits: leave-subjects-out CV only** (GroupKFold by person_id). Report per-fold and aggregate ROC/AUC, confusion matrix, feature importances.
3. **S3 (`models/train_gru.py`):** small GRU (≤100k params) on 10 Hz feature sequences; augmentation: temporal jitter, feature dropout, gaussian noise; same splits. Hyperparameter sweep on HyperAI 5090 overnight if local is slow (sync data via the 20 GB storage; nothing sensitive: features only).
4. **S1 baseline evaluated on identical splits** (thresholds are a classifier too; this comparison IS the wall chart).
5. **KSS correlation:** Spearman of S1/S2 score vs raw KSS, scatter plot.
6. **Flag decision (with the whole team):** S2 becomes `SCORER="fused"` primary only if it beats S1 on subject-disjoint AUC by a clear margin AND passes a live sanity hour on the booth webcam (no absurd outputs on the team). Otherwise thresholds ship and the wall reports the comparison honestly (a correct negative result is still a wall artifact).
7. **Export:** `models/export/` ONNX or pickled model + a loader in `perception/fatigue.py` behind the flag; sanity band vs S1 per TDD 4; latency re-measured with the model in path.
8. **Publish:** anonymized feature dataset (features + labels, no raw video, person_id re-hashed) to `data/export/` and into the repo with the dataset card + consent statement.

## Dev C tasks
1. Wall finalization: drop real charts into the P5 templates (EAR correction, S1-vs-S2-vs-S3 ROC, feature importances, KSS scatter, dataset card, latency panel screenshot, replay-CI stat from Dev A); bilingual captions; print run (A2/A3) at a local print shop or venue printer; backup: two laptops can display the wall if printing fails.
2. README upgrade: repo README as a short technical report embedding the same charts (this is what the code audit reads first).

## Acceptance
1. All evaluations subject-disjoint; the phrase appears on the chart itself.
2. Flag decision recorded in standup with the numbers that drove it.
3. Live sanity hour passed for whatever scorer ships.
4. Wall printed (or display-fallback staged); README shows the charts; dataset published with card.
5. `smoke.py` green with the shipped scorer configuration.

## Guardrails
- No test-set peeking, no split re-rolls until the number looks good, no random-split "backup numbers": one methodology, reported plainly. A judge who smells cherry-picking discounts everything else.
- If time collapses: keep dataset card + KSS scatter + S1-vs-S2 (drop S3 and the eye-CNN fine-tune first).
- Model work never touches the demo path except through the flag + sanity band.
