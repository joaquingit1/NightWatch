# P0 — Commit & Claim

**Objective:** retire every external dependency and freeze the contracts so P1/P2/P3 can start in parallel with zero coordination debt. Mostly ops; the only code deliverables are the repo skeleton and stubs.
**Read first:** `prds/00-OVERVIEW.md`. **Blocks:** everything. **Blocked by:** nothing.

## Workstreams (all three devs, ~2-3 hours, mostly parallel)

**All three together (first hour): the contracts session.**
- Walk through `00-OVERVIEW.md` contracts line by line; every dev states what they produce/consume; resolve disagreements NOW.
- Initialize repo: layout from overview, `contracts.py` implemented verbatim, `config.py` with initial flags (`SCORER="thresholds"`, `CAMERA_SOURCE="webcam"`, `EYE_CNN=False`, `VOICE=True`), empty `docs/standup.md`, `docs/stuck-log.md`, `.gitignore` (data/, *.db, *.wav except voice/clips).
- Agree git rules (overview) and stand-up times.

**Dev A (ops):** portal reads: official Reverse theme definition (paste into `docs/standup.md`), track cap (6 vs 8), exact deadline (1:00 vs 7:00 AM). Dimensional relationship: standing dog-station arrangement, join their Feishu group, book office-hours slot. Private network: travel router or dedicated phone hotspot up; SSID/password into `docs/standup.md`.

**Dev B (logistics):** ModelScope vendoring to ALL three laptops: Whisper (small/medium), MediaPipe Face Landmarker + Pose bundles, Qwen GGUF for Ollama (7-8B class), CosyVoice weights, MRL Eye + CEW datasets. Verify `ollama serve` + model responds on each laptop. Record download paths in `docs/standup.md`.

**Dev C (ops + stubs):** Perks sweep (30 min): OpenDev $500, OpenAgents $100, OneLinkAI, 清程, HyperAI code `HyperAI_AdventureX202607`, Qoder, Zion; record keys in a local `.env` (gitignored). Blue Box Feishu group: request mattress + pillow for the nap zone. Hardware pass at Endpoint G: Zilo rings, RDK X5, e-ink, GX10, spare Go2 battery (grab what exists, nothing blocks on it). Print run ordered: adoption stickers, signage, mat props. **Code:** `web/stub_server.py` serving all C5 endpoints with fake data (synthetic FatigueFrames at 2 Hz, scripted PolicyEvents, placeholder MJPEG from webcam or a looping video) and `robot/mock_facade.py` (all methods succeed after realistic delays: navigate 8 s, approach 5 s, sport 2 s, say = clip duration; logs every call).

## Acceptance (exit gate)
1. `git log` shows initialized repo with contracts, config, stubs; all three devs have pushed.
2. `python -m nightwatch.web.stub_server` serves; browser shows fake feed + ticker.
3. `python -c "from nightwatch.robot.mock_facade import MockFacade; MockFacade().sport('Hello')"` works.
4. Dog reachable on the private AP: `ping <ROBOT_IP>` <10 ms, 0% loss (Dev A demonstrates).
5. Theme definition, track cap, and deadline pasted in `docs/standup.md`; Ollama answers a prompt on all three laptops.

## Guardrails
- Do not start feature work in P0, even if idle: vendoring and claims have queues and human loops; finish them while humans are awake.
- If the Reverse definition contradicts our framing, flag immediately (theme choice is revisited before P9, nothing else changes).
