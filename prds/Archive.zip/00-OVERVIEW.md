# Night Watch — PRD Suite Overview & Execution Rules

**Read this file completely before executing any phase PRD.** It is the single source of truth for contracts, repo layout, lane ownership, and collaboration rules. Master context: `../PRD.md` (product), `../SLEEPINESS-PIPELINE-TDD.md` (perception design), `../TRACK-ANSWERS.md` (submission essays).

## What we are building (context capsule)

守夜犬 Night Watch: a Unitree Go2 robot dog (controlled exclusively through DimensionalOS over WebRTC) that autonomously patrols a hackathon venue, diagnoses human exhaustion from camera biometrics, escorts people to nap on a mattress, manages many concurrent naps like a nurse doing rounds (belongings checks, contactless breathing verification), and wakes each sleeper on time via a gentle escalation. Everything runs locally on laptops over a private Wi-Fi network; there is no cloud in the demo path. Deadline: submission July 26 1:00 AM; live expo judging July 26 morning. The demo must not fail: demo-critical work always outranks feature work.

## The three lanes (strict directory ownership)

| Lane | Owner | Directories owned | Mission |
|---|---|---|---|
| A: Robot & Behavior | Dev A | `nightwatch/robot/`, `nightwatch/policy/` | Dog connectivity, navigation, escalation FSM, wake ladder, scheduler |
| B: Perception | Dev B | `nightwatch/perception/`, `nightwatch/models/` | FatigueEngine, pose-corrected EAR, eye CNN, breathing, training |
| C: Product, UI & Data | Dev C | `nightwatch/web/`, `nightwatch/capture/`, `nightwatch/ledger/`, `nightwatch/voice/` | Booth UI, capture app + dataset, ledger, voice library, assets |

**Rule 1: never edit files outside your lane's directories**, except `tests/` (anyone may add tests) and `docs/stuck-log.md` (everyone appends). All cross-lane needs are served by the contracts below. If you need something from another lane, write a stub against the contract and post a note in the stand-up file (`docs/standup.md`), do not reach into their code.

**Rule 2: `nightwatch/contracts.py` is frozen after P0.** Changing it requires agreement of all three devs recorded in `docs/standup.md`. If a contract seems wrong while you execute, STOP and flag it; do not unilaterally change or work around it.

**Rule 3: everything experimental ships behind a flag.** The demo path (thresholds scorer, FSM, UI) must keep working after every commit. `python -m nightwatch.smoke` must pass before every push (P1 creates it).

## Contracts (authoritative spec; implement exactly this in `nightwatch/contracts.py`)

```python
from dataclasses import dataclass, field

# C1a: per-frame features (shared by runtime and training; NEVER fork this)
@dataclass
class FeatureVector:
    ts: float                 # unix seconds
    ear_l: float; ear_r: float
    ear_corrected: float      # pose-corrected, canonical-frame EAR (mean of eyes)
    eye_cnn_p: float          # P(eyes closed) from CNN channel; -1.0 if channel disabled
    mar: float                # mouth aspect ratio
    head_pitch: float; head_yaw: float; head_roll: float   # degrees
    pitch_vel: float          # deg/s
    slump_deg: float          # neck-torso angle deviation; -1.0 if body pose unavailable
    movement: float           # frame-to-frame keypoint displacement (normalized)
    quality: float            # 0-1 landmark quality; gate features on this

# C1b: windowed fatigue output (Perception -> Policy, UI)
@dataclass
class FatigueFactors:
    perclos: float; blink_ms_p50: float; blink_ms_p90: float
    nod_count: int; yawn_count: int; slump_deg: float
    eye_cnn_perclos: float; movement_entropy: float; sedentary_hours: float

@dataclass
class FatigueFrame:
    ts: float
    person_id: str | None     # reid id for adopters; None for anonymous triage
    bbox: tuple[int, int, int, int]
    score: float              # 0-100 RestScore
    confidence: float         # 0-1; UI/policy must treat < 0.5 as "no reading"
    factors: FatigueFactors
    calib_state: str          # "uncalibrated" | "quick" | "full"
    scorer: str               # "thresholds" | "lgbm" | "fused"

# C2: policy transitions (Policy -> UI ticker, Ledger)
@dataclass
class PolicyEvent:
    ts: float
    state: str        # see FSM states below
    target_person: str | None
    utterance: str | None    # voice clip id spoken, if any
    detail: str              # human-readable, bilingual "zh | en"

# C4: robot facade (Policy -> Dog). Implement real + mock with identical signatures.
class RobotFacade:                # Protocol; robot/facade.py (real), robot/mock_facade.py
    def navigate_to(self, tag: str) -> bool: ...      # premapped location tag
    def approach(self, person_id: str) -> bool: ...   # visual servo to person
    def sport(self, cmd: str) -> bool: ...            # "Sit"|"StandUp"|"StandDown"|"Hello"|"Stretch"|"WiggleHips"
    def say(self, clip_id: str) -> bool: ...          # pre-rendered clip id (voice/clips/{id}.wav)
    def observe(self) -> "np.ndarray | None": ...     # current camera frame (BGR)
    def stop(self) -> None: ...                       # emergency stop, must be instant
    def status(self) -> dict: ...                     # {"battery": float, "connected": bool, "pose": ...}

# C6: capture record (Capture app -> dataset). Features via the SAME FeatureExtractor.
@dataclass
class CaptureRecord:
    session_id: str; person_id: str
    ts_start: float; fps: float
    features: list[FeatureVector]
    kss: int                  # 1-9 Karolinska self-rating
    hours_awake: float; glasses: bool; lighting: str   # "bright"|"normal"|"dim"
    consent_raw_video: bool   # raw video stored only if True
```

**FSM states (exact strings for PolicyEvent.state):** `IDLE, PATROL, TRIAGE, APPROACH, DIAGNOSE, PRESCRIBE, ESCORT, NAP_REGISTERED, PASS_CHECK, DETER, WAKE_LADDER, CELEBRATE, RESET, ESTOP`.

**C3 Ledger API + C5 UI endpoints (served by `nightwatch/web/server.py`):**
- `GET /video_feed/pov`, `GET /video_feed/annotated` (MJPEG, multipart/x-mixed-replace)
- `GET /text_stream/thoughts` (SSE of PolicyEvent as JSON)
- `GET /api/score` (latest FatigueFrame as JSON), `GET /api/ledger`, `GET /api/leaderboard`
- `POST /api/adopt` (adoption form), `POST /api/capture` (CaptureRecord), `POST /api/outcome` (nap survey)
- Ledger SQLite tables: `persons(person_id, name_alias, adopted_ts, baseline_json)`, `naps(nap_id, person_id, start_ts, onset_ts, wake_deadline, woke_ts, outcome)`, `events(ts, state, person_id, detail)`, `passes(ts, nap_id, position_ok, breathing_rpm, belongings_ok, frame_path)`.

**Voice clips:** every dog utterance is a pre-rendered WAV in `nightwatch/voice/clips/`, id'd like `greet_01`, `verdict_score_74`, `wake_whisper_01`. Policy code references clip ids only; it never synthesizes text at runtime (scores 0-100 are pre-rendered per number).

## Repo layout

```
nightwatch/
  contracts.py  smoke.py  config.py (all flags live here)
  robot/     facade.py mock_facade.py skills.py conn_check.py
  policy/    escalation.py wake_ladder.py scheduler.py director.py
  perception/ features.py ear.py eye_cnn.py fatigue.py breathing.py calib.py sources.py
  models/    train_lgbm.py train_gru.py eval.py export/
  web/       server.py stub_server.py static/booth.html static/wall/
  capture/   app.py
  ledger/    db.py schema.sql
  voice/     render.py clips/
tests/       (golden vectors: tests/golden/feature_vectors.json)
docs/        standup.md stuck-log.md
data/        (gitignored; dataset export script writes data/export/)
```

## Collaboration mechanics

- **Git:** trunk-based on `main`, small commits, push at least every 2 hours. Directory ownership makes conflicts structurally impossible. Never rewrite history (the hackathon audits commit history). Commit messages: plain, honest, present tense. **No AI co-author trailers of any kind.**
- **Stand-ups:** 3× daily, 5 minutes, appended to `docs/standup.md`: done / next / blocked / contract-change requests.
- **Stuck log:** every real blocker + fix goes to `docs/stuck-log.md` same day (this feeds a scored submission question; it is not optional).
- **Integration checkpoints:** I1 Perception→UI on webcam; I2 Perception→Policy on mock facade; I3 Policy→real dog; I4 full loop. Each has an owner pair and a demo-able definition in the phase PRDs.
- **Stubs ship first:** P0/P1 check in `web/stub_server.py` (fake streams on all C5 endpoints), `robot/mock_facade.py`, and a fake FatigueFrame generator, so every lane integrates continuously from hour one.

## Execution guidance for AI executors

You may be an AI model executing one phase PRD. Hold this bar:
1. Read this overview + your phase PRD fully before writing code. Do not invent scope; if the PRD is ambiguous, choose the simplest interpretation that satisfies the acceptance tests and note the choice in `docs/standup.md`.
2. Write boring, typed, documented Python 3.12. Every module runnable standalone (`python -m nightwatch.<module>` demos it). Unit tests for pure math (EAR, PERCLOS windowing, scheduler) in `tests/`.
3. Never touch: other lanes' directories, `contracts.py`, DimOS internals (we consume DimOS as a library; workarounds live in our code, never patches to theirs unless the phase PRD says so).
4. Feature flags in `config.py`, default = demo-safe value.
5. Acceptance tests in the phase PRD are the definition of done. All of them, not most.
6. Match the codebase's existing style. Comments only for non-obvious constraints. No em dashes in any written output, code comments, or docs.
```
