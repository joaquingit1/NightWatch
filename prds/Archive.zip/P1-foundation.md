# P1 — Foundation (Dev A lane; B and C proceed to P2/P5 in parallel)

**Objective:** kill the two existential risks: (1) we can command the dog through DimOS on our own network, (2) the full agent loop runs on a local LLM with zero internet. Also ship the smoke test every later phase relies on.
**Read first:** `00-OVERVIEW.md`. **Blocks:** P3 (I3). **Does NOT block:** P2, P5 (they run on webcam + stubs).

## Context an executor needs
DimOS (`pip install 'dimos[base,unitree]'`, Python 3.12, repo github.com/dimensionalOS/dimos) drives a stock Go2 over WebRTC. Key verified facts: `dimos go2tool connect-wifi --ssid <s> --password <p>` provisions the dog onto our AP (BLE); `dimos go2tool discover` prints its IP; `export ROBOT_IP=...; dimos run unitree-go2` starts nav + browser command center (localhost:7779). Blueprint `unitree-go2-agentic-ollama` runs the LangGraph agent against local Ollama. Skills exist for `relative_move`, `execute_sport_command` (Sit/StandUp/StandDown/Hello/Stretch/WiggleHips), `speak`, `observe`, `navigate_with_text`, `tag_location`, `follow_person`. Sim/replay (`dimos --replay run unitree-go2`, `dimos --simulation run unitree-go2-agentic`) works with no hardware.

## Tasks (Dev A, in order)
1. **Environment:** uv venv per overview; install `dimos[base,unitree]`; run the replay blueprint (downloads ~75 MB LFS on first run) and the MuJoCo sim blueprint. Both must render.
2. **Real dog bring-up:** provision to our AP, verify <10 ms ping, `dimos run unitree-go2-basic` then full `unitree-go2`; confirm command center + Rerun show video/map. Note firmware version.
3. **Sport + speech sanity:** via `dimos mcp call`, exercise every sport command in the C4 list and `speak`. Record which work on this firmware in `docs/standup.md` (fallbacks if any fail: WiggleHips and Stretch are personality-optional).
4. **Local agent loop:** `dimos run unitree-go2-agentic-ollama` with the vendored Qwen model; `dimos agent-send "walk half a meter forward and say hello"` must produce movement + speech with Wi-Fi upstream disconnected (unplug the router's WAN / disable hotspot data to prove zero-internet).
5. **Real RobotFacade (`robot/facade.py`):** implement C4 exactly, wrapping DimOS skills (MCP calls or module RPC, whichever is more reliable in practice). `say(clip_id)` plays `voice/clips/{id}.wav` through the robot speaker if the speak channel accepts audio, else through a laptop speaker positioned at the dog (decide, document in stuck-log). `stop()` must interrupt any in-flight action.
6. **Smoke test (`nightwatch/smoke.py`):** one command that (a) imports contracts, (b) starts stub server, hits every C5 endpoint, (c) instantiates Mock and (if `ROBOT_IP` set) real facade and calls `status()`. Exit 0/1. This becomes the pre-push gate for everyone.
7. **Premap dry run:** record a small area with `unitree-go2-memory`, run the relocalization workflow once end to end so P3's venue premap is a repeat, not a first attempt.

## Acceptance
1. Video of: agent-sent natural-language command → dog moves and speaks, with upstream internet visibly off.
2. `python -m nightwatch.smoke` passes on Dev A's machine with the real dog and on B/C machines with mock only.
3. `robot/facade.py` passes a scripted sequence: navigate_to(tag) on the dry-run premap, sport("Hello"), say(test clip), stop() mid-navigation halts within 1 s.
4. Stuck-log has ≥1 real entry (there will be one).

## Guardrails
- Do not patch DimOS source; wrap problems in `facade.py` and file them in stuck-log. If a DimOS bug is fatal, use their office hours (booked in P0) same day.
- Do not tune navigation beyond "works in the dry-run area"; venue premap quality is P3's job.
- Battery discipline starts now: dog on charger whenever not actively testing.
