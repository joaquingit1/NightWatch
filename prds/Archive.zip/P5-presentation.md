# P5 — Presentation: Booth UI, Voice, Wall (Dev C lane; starts at P0 against the stub server)

**Objective:** everything a judge sees or hears: the booth page, the thought ticker, the voice library, the engineering wall scaffolding, all bilingual (Chinese-first), all self-healing.
**Read first:** `00-OVERVIEW.md` (C5 endpoints are the contract; develop 100% against `stub_server.py` until I1). **Blocks:** I1, P6 filming quality. **Blocked by:** nothing.

## Tasks

1. **`web/server.py` (real):** FastAPI serving C5 exactly. Video: MJPEG generators consuming the annotated/raw frame callbacks from perception (pattern: internal queue per stream, drop-oldest). Thoughts: SSE of PolicyEvents as JSON. APIs proxy `ledger/db.py`. Same process also mounts the capture app routes. If integrating DimOS's RobotWebInterface proves faster for MJPEG, wrapping it is acceptable; the endpoint URLs must not change.
2. **`web/static/booth.html`:** single dark page, readable at 3 m, no build toolchain (vanilla JS + one CSS file):
   - Layout: annotated feed 60% left; right column = live score card (big number, factor bars, confidence state, calib state), thought ticker (auto-scroll, zh line + smaller en line), plan strip (`/api/plan` route + ETAs), ledger stats + leaderboard rotation.
   - Self-healing: `<img>` MJPEG elements re-src on stall (watchdog timer checks last-frame age via a heartbeat endpoint), SSE auto-reconnect with backoff, explicit "重新连接中 reconnecting" overlays, never a frozen frame presented as live.
   - Branding: 守夜犬 Night Watch + thesis line "每个 AI 都想让你更努力。它想让你休息。/ Every AI makes you work more. This one makes you stop."
   - States: kiosk mode (diagnosis only, for I1 and fallback), full mode, replay mode (plays golden-run footage + recorded ticker when `DEMO_MODE="replay"`).
3. **`voice/render.py` + clips:** collect the clip list from Dev A (standup); write bilingual scripts (zh primary, warm caregiver tone, short sentences); render via CosyVoice (vendored weights; HyperAI 5090 if local render is slow); MUST include `verdict_score_0..100` (zh) batch, wake whispers at low gain, greet/prescribe/decline/deter/celebrate variants (2-3 each to avoid repetition). Loudness-normalize; test through the actual output chain (robot speaker or staged speaker) at expo-noise volume.
4. **Engineering wall scaffolding (`web/static/wall/`):** templated A2/A3 print layouts (HTML → PDF ok): architecture "used vs wrote" two-column; slots for: ear_correction.png (P2), ROC + feature importances + KSS scatter (P7), latency panel screenshot, replay-CI stat, dataset card. Bilingual captions. Print run happens in P7/P8; the templates and diagrams that don't depend on results are finished NOW.
5. **Latency panel:** small overlay on booth page fed by timing measurements Dev B exposes (per-stage ms: capture → landmarks → features → score) + end-to-end.
6. **Assets:** adoption sticker final art, consent explainer sign, one-poster (USP / markets / RaaS pricing line), RED cover art (Zion Nano Banana acceptable here and only here).

## Acceptance
1. Booth page runs 4+ hours against the stub server with induced failures (kill stub, restart: page self-heals without manual refresh).
2. I1: same page against real perception (webcam): judge-facing kiosk demo complete: lock ≤3 s, score card live, annotated feed smooth ≥10 fps.
3. Voice: blind test on a non-team Chinese speaker: "does this sound warm, not robotic?" passes; all clips play through the demo output chain; every clip id referenced by `policy/` exists (`python -m nightwatch.voice.render --check` verifies against a registry file).
4. Replay mode plays recorded footage + ticker convincingly (this is fallback rung 4).
5. Wall templates render to printable PDFs with placeholder charts.

## Guardrails
- No frontend frameworks/build steps; the whole UI must be debuggable at 3 AM by anyone.
- Chinese text reviewed by a native/fluent speaker before rendering voice or printing (ask in the team's local network; do not ship machine-translated text unreviewed).
- Policy code references clip ids only; never add runtime TTS synthesis (latency + failure surface).
